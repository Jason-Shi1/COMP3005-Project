
//Book Insertion Queries

SELECT * FROM BOOK

INSERT INTO BOOK VALUES(88888888, 'Harry Potter', 'J.K Rowling', 'Fantasy', 'Bloomsburry', 592 , 20);
INSERT INTO BOOK VALUES(77777777, 'The Thing', 'Steven King', 'Horror', 'Bloomsburry', 465 , 30);
INSERT INTO BOOK VALUES(66666666, 'The Choice', 'Nora Roberts', 'Novel', 'HarperCollins', 230 , 10);
INSERT INTO BOOK VALUES(55555555, 'The Devil Wears Prada', 'Stephen King', 'Fiction', 'Macmillan Publishers', 230 , 10);

//User Insertion Queries

INSERT INTO user VALUES('user1@gmail.com', 'Jay', '113 Maple Street', '756 Apple Street');
INSERT INTO USER VALUES('user2@gmail.com', 'Michael', '234 Prune Street', '854 Kiwi Street');

//Checkout Basket Insertion Queries

INSERT INTO checkout_basket VALUES('user1@gmail.com', 88888888, 1);
INSERT INTO checkout_basket VALUES('user2@gmail.com', 55555555, 1);

//Order Insertion Queries

INSERT INTO orders ('user1@gmail.com', '113 Maple Street', '756 Apple Street', 482, 50) VALUES('user1@gmail.com', '113 Maple Street', '756 Apple Street', 128 , 0);


//Book Removal Queries

DELETE FROM BOOK WHERE ISBN = 88888888;
DELETE FROM BOOK WHERE NAME = 'Harry Potter';


//Selecting specific book

SELECT * FROM BOOK WHERE NAME = 'Harry Potter'
SELECT * FROM BOOK WHERE ISBN = 88888888;
