//DDL Statements that create the tables and their relations for the database.




		"CREATE TABLE PUBLISHER("
                        "PUBLISHER_NAME     TEXT, "
                        "ADDRESS            TEXT    NOT NULL, "
                        "EMAIL              TEXT    NOT NULL, "
                        "PHONENUM           TEXT    NOT NULL, "
                        "BANKACC            TEXT    NOT NULL,"
                        "PRIMARY KEY (PUBLISHER_NAME)"
                        ");"
                        

		"CREATE TABLE BOOK("
                        "ISBN         INTEGER, "
                        "NAME         TEXT      NOT NULL, "
                        "AUTHOR       TEXT      NOT NULL, "
                        "GENRE        TEXT      NOT NULL, "
                        "PUBLISHER    TEXT      NOT NULL, "
                        "PAGES        INTEGER   NOT NULL," 
                        "COST         INTEGER   NOT NULL,"
                        "PRIMARY KEY (ISBN)"
                        "FOREIGN KEY(PUBLISHER) REFERENCES PUBLISHER(PUBLISHER_NAME)"
                        ");"

                        
                "CREATE TABLE ORDERS("
                        "ORDER_NUMBER   INTEGER, "
                        "BOOK_NAME      TEXT    NOT NULL, "
                        "SHIPPING_INFO  TEXT    NOT NULL, "
                        "BILLING_INFO   TEXT    NOT NULL, "
                        "TRACKING_NUM   INTEGER     NOT NULL, "
                        "COST           INTEGER     NOT NULL,"
                        "PRIMARY KEY (ORDER_NUMBER)"
                        ");"
                        

               	"CREATE TABLE ORDERS_REQUEST("
                        "ORDER_NUMBER   INTEGER, "
                        "ISBN           INTEGER, "
                        "QUANTITY       INTEGER     NOT NULL,"
                        "PRIMARY KEY (ORDER_NUMBER, ISBN)"
                        "FOREIGN KEY(ORDER_NUMBER) REFERENCES ORDERS(ORDER_NUMBER)"
                        "FOREIGN KEY(ISBN) REFERENCES BOOK(ISBN)"
                        ");"


                "CREATE TABLE USER("
                        "EMAIL          TEXT, "
                        "NAME           TEXT, "
                        "BILLING_INFO   TEXT    NOT NULL,"
                        "SHIPPING_INFO  TEXT    NOT NULL, "
                        "PRIMARY KEY (EMAIL)"
                        ");"


                "CREATE TABLE SUBMIT("
                        "ORDER_NUMBER   INTEGER, "
                        "USER_EMAIL     TEXT, "
                        "PRIMARY KEY (ORDER_NUMBER, USER_EMAIL)"
                        "FOREIGN KEY(ORDER_NUMBER) REFERENCES ORDERS(ORDER_NUMBER)"
                        "FOREIGN KEY(USER_EMAIL) REFERENCES USER(EMAIL)"
                        ");"


                "CREATE TABLE CHECKOUT_BASKET("
                        "USER_EMAIL     TEXT, "
                        "ISBN           INTEGER     NOT NULL, "
                        "QUANTITY       INTEGER     NOT NULL, "
                        "PRIMARY KEY (USER_EMAIL)"
                        "FOREIGN KEY(USER_EMAIL) REFERENCES USER(EMAIL)"
                        "FOREIGN KEY(ISBN) REFERENCES BOOK(ISBN)"
                        ");"