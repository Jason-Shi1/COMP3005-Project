Group Members: Jason Shi & Jin Jung

Instructions: The program runs in C++ and also uses the sqlite3 library. Please make sure the sqlite3 library is installed on your machine. Download link: https://sqlite.org/cli.html
Next, once you are in the COMP3005Project directory you can compile the files using the makefile by running the "make" command or alternatively by running: "g++ -o a1 main.cc -l sqlite3". 
This will generate the "a1" file and you can run the a1 file by typing "./a1" in the command line.
Once the ./a1 program has been executed it will generate "library.db" where all of the SQL tables and queries are stored.
You can test and run the implementation through the ./a1 file by inputting the numbers that correspond to commands to execute those commands.
Any commands or queries that are executed in the program such as adding or removing a book from the library will be refleceted in "library.db" 
There is also a "make clean" command available that you can use to remove the current "./a1" file and "library.db" file if you would like to recompile or have a fresh "library.db".
The SQL files are also located within the "SQL" folder in the COMP3005Project directory.